# NOIR 713 — Houston After Dark

Concept website redesign. Responsive, accessible black, champagne-gold and burgundy design based on the supplied image collage. All local artwork is illustrative. No venue, operational status, opening date, reservation contact or pricing has been confirmed.

## Local preview
Open `index.html` in a web browser. For best compatibility run `python -m http.server 8000` within the folder and visit `http://localhost:8000`.

## Deployment
Copy `index.html` and `assets/images/*` into the GitHub Pages repository root, enable Pages for the main branch, and verify mobile and desktop display. The contact form creates an email draft without a verified recipient. Add a real business email address when available.
